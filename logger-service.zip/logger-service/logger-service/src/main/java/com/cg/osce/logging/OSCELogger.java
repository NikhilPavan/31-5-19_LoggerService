package com.cg.osce.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.osce.logging.model.Log;
import com.cg.osce.logging.utils.Utils;

import ch.qos.logback.classic.Level;

@SpringBootApplication
public class OSCELogger {

	private static final Logger LOGGER = LoggerFactory.getLogger(OSCELogger.class);

	//To Log Requests
	public void log(String application, String module, Level level, String messageType, Object[] requestParams,
			String processId, String source) {

		String logMessage = Utils.getLoggableString(application, module, messageType, requestParams, null, processId,
				source, null, null);

		LOGGER.info(logMessage);
		LOGGER.debug(logMessage);
	}

	//To Log Resposne
	public void log(String application, String module, Level level, String messageType, Object response,
			String processId, String destination, String status) {

		String logMessage = Utils.getLoggableString(application, module, messageType, null, response, processId, null,
				destination, status);

		LOGGER.info(logMessage);
		LOGGER.debug(logMessage);
	}

	//To Log Events
	public void log(String application, String module, Level level, String messageType, String processId,
			String status) {

		String logMessage = Utils.getLoggableString(application, module, messageType, null, null, processId, null, null,
				status);

		LOGGER.info(logMessage);
		LOGGER.debug(logMessage);
	}

	public static void main(String[] args) {
		System.err.println("asdfasdf");
		SpringApplication.run(OSCELogger.class, args);
		OSCELogger logger = new OSCELogger();
		Object[] objectarray = new Object[] { 1, "helloworld" };
		logger.log("logger-service", "testLogging", Level.DEBUG, "Request", objectarray, "123wer", "LogTestSource");
		Log log = new Log();
		log.setApplication("application");
		log.setModule("module");
		log.setMessageType("messageType");
		log.setRequestParams(objectarray);
		logger.log("logger-service", "testLogging", Level.DEBUG, "Response", log, "123wer", "LogTestDestination",
				"Success 200");

	}
}
