package com.cg.osce.logging.model;

import lombok.Data;

@Data
public class Log {

	private String application;

	private String module;
	
	private String timeStamp;

	private String messageType;

	private Object[] requestParams;

	private Object responseMessage;
	
	private String Latency;

	private String processId;
	
	private String entityId;

	private String source;

	private String destination;

	private String Status;

}
